from pytube import YouTube

link = input("Paste the link Here")
youtube_1 = YouTube(link)

videos = youtube_1.streams.all()
vid = list(enumerate(videos))
for i in vid:
    print(i)

strm = int(input("enter: "))
videos[strm].download()
print("Download Successful")

