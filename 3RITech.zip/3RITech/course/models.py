from django.db import models

class Courses(models.Model):
    cimg=models.CharField(max_length=800)
    cdesc=models.CharField(max_length=800)
    cname=models.CharField(max_length=100)
    cduration=models.CharField(max_length=50)

    def _str_(self):
        return self.cname


    class Meta:
        db_table="course"

# Create your models here.
