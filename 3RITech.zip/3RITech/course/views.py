from django.shortcuts import render
from .models import Courses

def courses(request):
    courses=Courses.objects.all()
    return render(request,'course.html',{'courses':courses})



# Create your views here.
