from django.contrib import admin
from .models import Courses
admin.site.register(Courses)

# Register your models here.
