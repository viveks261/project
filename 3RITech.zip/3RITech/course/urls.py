from django.contrib import admin
from django.urls import path
from course.views import courses

urlpatterns = [
    path('courses/',courses,name='courses'),



]