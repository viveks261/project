from django.contrib import admin
from django.urls import path
from .views import signup
#from django.contrib.staticfiles.urls import staticfiles_urlpatterns

urlpatterns = [
    path('admin/', admin.site.urls),
    path('signup/',signup,name='signup'),

]
#urlpatterns += staticfiles_urlpatterns()