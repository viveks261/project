from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render
from signup.forms import SignupForm
from django.contrib import messages
from django.utils.safestring import mark_safe



def signup(request):
    if request.method=="POST":
        #fm=UserCreationForm(request.POST)
        fm=SignupForm(request.POST)
        if fm.is_valid():
            fm.save()
            messages.success(request, mark_safe("Thanks for signing up. Your account has been created. <a href='http://127.0.0.1:8000/signin/'>click here to login</a>"))
    else:
        #fm=UserCreationForm()
        fm = SignupForm()

    return render(request,'signupform.html',{'form':fm})

