from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm
from django.shortcuts import render

def signin(request):
    if request.method=="POST":
        fm=AuthenticationForm(request=request,data=request.POST)
        if fm.is_valid():
            uname=fm.cleaned_data['username']
            pass1=fm.cleaned_data['password']
            user=authenticate(username=uname,password=pass1)
            if user is not None:
                login(request,user)
            return render(request,'select.html')
    else:
        fm=AuthenticationForm()
    return render(request,"signinform.html",{'form':fm})

# Create your views here.

