from django.contrib import admin
from django.urls import path
from .views import signin

urlpatterns = [
    path('admin/', admin.site.urls),
    path('signin/',signin,name='signin'),

]

