from django.shortcuts import render,HttpResponse

# Create your views here.
from contact.models import Contact
from datetime import datetime
from django.contrib import messages


def contact(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        desc = request.POST.get('desc')
        contact = Contact(name=name, email=email, phone=phone, desc=desc, date = datetime.today())
        contact.save()
        messages.success(request, 'Thank you! Your message has been successfully sent. We will contact you very soon!')

    return render(request, 'contact.html')