from django.contrib import admin
from django.urls import path
from .views import attendance

urlpatterns = [
    path("attendance",attendance,name='attendance'),

]