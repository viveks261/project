from django.shortcuts import render
from django.shortcuts import render,HttpResponse

# Create your views here.
from attendance.models import Attendance
from datetime import datetime
from django.contrib import messages
from django.utils.safestring import mark_safe


def attendance(request):
    if request.method == "POST":
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        attendance = Attendance(first_name=first_name, last_name=last_name,date=datetime.today())
        #attendance.save()
        messages.success(request, mark_safe("Thank you! Your Attendance Submitted Successfully!. <a href='http://127.0.0.1:8000/'>Back to the Homepage</a>"))


    return render(request,'attendance.html')