from django.db import models

# makemigrations - create changes and store in a file
# migrate - apply the pending changes created by makemigrations

# Create your models here.
class Attendance(models.Model):
    first_name = models.CharField(max_length=122)
    last_name=models.CharField(max_length=100)
    date= models.DateField()

    def _str_(self):
        return self.first_name



