from django.contrib import admin
from .models import Attendance
admin.site.register(Attendance)

