from django.shortcuts import render,HttpResponse

# Create your views here.
from admission.models import Admission
from datetime import datetime
from django.contrib import messages


def admission(request):
    if request.method == "POST":
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        phone = request.POST.get ('phone')
        course = request.POST.get('course')
        admission = Admission(first_name=first_name,last_name=last_name, email=email, phone=phone, course=course, date = datetime.today())
        admission.save()
        messages.success(request, 'Thank you! Your form has been sent successfully. We will contact you very soon!')

    return render(request, 'admission.html')