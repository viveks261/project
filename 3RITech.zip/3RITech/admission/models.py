from django.db import models

# makemigrations - create changes and store in a file
# migrate - apply the pending changes created by makemigrations

# Create your models here.
class Admission(models.Model):
    first_name = models.CharField(max_length=122)
    last_name=models.CharField(max_length=100)
    email = models.CharField(max_length=122)
    phone = models.CharField(max_length=12)
    course=models.CharField(max_length=100)
    date= models.DateField()

    def _str_(self):
        return self.course
